<template>
  <div class="work">
  	<div class="project-card" v-for="project in projects">
	  	<router-link :to="{ name: 'Project', params: { projectId: project.projectId }}" @mouseenter.native="makeActive(project)" @mouseleave.native="makeInactive(project)">
	  		<img v-show="!project.active" :src="previewUrl( project.thumbnail )">
	  		<img v-show="project.active" :src="previewHoverUrl( project.thumbnail )">
	  		<h4>{{ project.title }}</h4>
  		</router-link>
  	</div>
  </div>
</template>

<script>
import projects from '../assets/projects-data.json'
projects.forEach(function(p) { p.active = false })

export default {
  name: 'work',
  data () {
    return {
      projects: projects,
    }
  },
  methods: {
  	previewUrl: function(name) {
  		return "/static/images/previews/" + name + "-preview@0,5x.jpg"
  	},
  	previewHoverUrl: function(name) {
  		return "/static/images/previews/" + name + "-preview-active@0,5x.jpg"
  	},
  	makeActive: function(project) {
  		project.active = true;
  	},
  	makeInactive: function(project) {
  		project.active = false;
  	}
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
